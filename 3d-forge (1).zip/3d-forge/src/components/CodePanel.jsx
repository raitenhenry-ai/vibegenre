import T from '../theme';

export default function CodePanel({ code, setCode, onRun }) {
  const handleKeyDown = (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      onRun();
    }
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.target;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const val = ta.value;
      ta.value = val.substring(0, start) + '  ' + val.substring(end);
      ta.selectionStart = ta.selectionEnd = start + 2;
      setCode(ta.value);
    }
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <textarea
        value={code}
        onChange={(e) => setCode(e.target.value)}
        onKeyDown={handleKeyDown}
        spellCheck={false}
        style={{
          flex: 1, resize: 'none', border: 'none', outline: 'none',
          background: T.bg, color: T.code, fontFamily: T.font,
          fontSize: 12.5, lineHeight: 1.6, padding: 16,
          tabSize: 2, overflow: 'auto',
        }}
      />
      <div style={{
        padding: '8px 16px', borderTop: `1px solid ${T.panelBorder}`,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <span style={{ fontSize: 10, color: T.textMuted }}>⌘+Enter to run</span>
        <button onClick={onRun} style={{
          padding: '5px 12px', borderRadius: 6, border: `1px solid ${T.accent}44`,
          cursor: 'pointer', background: T.accentDim, color: T.accent,
          fontWeight: 600, fontSize: 11, fontFamily: T.font,
          transition: 'all 0.15s',
        }}>
          ▶ Run Code
        </button>
      </div>
    </div>
  );
}
