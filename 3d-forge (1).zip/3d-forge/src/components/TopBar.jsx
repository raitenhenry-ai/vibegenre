import { useState } from 'react';
import { useAuth } from '../App';
import T from '../theme';

export default function TopBar({ codeError, onRun }) {
  const { user, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div style={{
      height: 52, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 16px', borderBottom: `1px solid ${T.panelBorder}`,
      background: `linear-gradient(180deg, ${T.panel} 0%, ${T.bg} 100%)`,
      flexShrink: 0,
    }}>
      {/* Left: Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 30, height: 30, borderRadius: 7,
          background: `linear-gradient(135deg, ${T.accent}, #007a55)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 15, fontWeight: 800, color: '#000',
          boxShadow: T.accentGlow,
        }}>◇</div>
        <span style={{ fontFamily: T.fontSans, fontWeight: 800, fontSize: 16, letterSpacing: '-0.03em' }}>
          3D FORGE
        </span>
        <span style={{
          fontSize: 10, color: T.textDim, padding: '2px 7px', borderRadius: 4,
          background: T.surface, border: `1px solid ${T.panelBorder}`,
        }}>
          BETA
        </span>
      </div>

      {/* Center: Error display */}
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
        {codeError && (
          <span style={{
            fontSize: 11, color: T.error, maxWidth: 400,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            padding: '4px 10px', borderRadius: 6, background: `${T.error}15`,
          }}>
            ⚠ {codeError}
          </span>
        )}
      </div>

      {/* Right: Run + User */}
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button onClick={onRun} style={{
          padding: '7px 16px', borderRadius: 7, border: 'none', cursor: 'pointer',
          background: T.accent, color: '#000', fontWeight: 700, fontSize: 12,
          fontFamily: T.font, transition: 'all 0.15s',
          boxShadow: T.accentGlow,
        }}>
          ▶ Run
        </button>

        {/* User avatar */}
        <div style={{ position: 'relative' }}>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            style={{
              width: 32, height: 32, borderRadius: '50%', border: `2px solid ${T.panelBorder}`,
              background: `linear-gradient(135deg, ${T.accent}44, ${T.surface})`,
              color: T.accent, fontWeight: 700, fontSize: 13, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: T.fontSans, transition: 'all 0.15s',
            }}
          >
            {user?.name?.charAt(0).toUpperCase() || '?'}
          </button>

          {menuOpen && (
            <>
              <div onClick={() => setMenuOpen(false)} style={{
                position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99,
              }} />
              <div style={{
                position: 'absolute', top: 40, right: 0, zIndex: 100,
                background: T.panel, border: `1px solid ${T.panelBorder}`,
                borderRadius: 10, padding: 8, minWidth: 180,
                boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
              }}>
                <div style={{
                  padding: '8px 12px', fontSize: 12, color: T.textDim,
                  borderBottom: `1px solid ${T.panelBorder}`, marginBottom: 4,
                  fontFamily: T.fontSans,
                }}>
                  {user?.email}
                </div>
                <button onClick={logout} style={{
                  width: '100%', padding: '8px 12px', border: 'none', borderRadius: 6,
                  background: 'transparent', color: T.error, fontSize: 13,
                  fontFamily: T.fontSans, cursor: 'pointer', textAlign: 'left',
                  transition: 'background 0.15s',
                }}
                  onMouseEnter={(e) => e.target.style.background = T.surface}
                  onMouseLeave={(e) => e.target.style.background = 'transparent'}
                >
                  Sign Out
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
