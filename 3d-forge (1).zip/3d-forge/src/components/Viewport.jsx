import { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { executeCode } from '../utils/executeCode';
import T from '../theme';

export default function Viewport({ code, onError }) {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const frameRef = useRef(null);
  const mouseRef = useRef({ isDown: false, x: 0, y: 0 });
  const rotRef = useRef({ x: 0.5, y: 0.8 });
  const zoomRef = useRef(8);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(T.bg);
    scene.fog = new THREE.Fog(T.bg, 15, 40);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(50, mount.clientWidth / mount.clientHeight, 0.1, 100);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    mount.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    const ambient = new THREE.AmbientLight(0x404060, 0.6);
    scene.add(ambient);
    const key = new THREE.DirectionalLight(0xffffff, 1.2);
    key.position.set(5, 8, 5);
    key.castShadow = true;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0x4488ff, 0.3);
    fill.position.set(-5, 3, -5);
    scene.add(fill);
    const rim = new THREE.PointLight(0x00e5a0, 0.5, 20);
    rim.position.set(0, 5, -5);
    scene.add(rim);

    // Grid
    const grid = new THREE.GridHelper(20, 20, 0x1e1e2e, 0x14141f);
    grid.position.y = -1.5;
    scene.add(grid);

    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);
      const r = rotRef.current;
      const z = zoomRef.current;
      camera.position.set(
        z * Math.sin(r.y) * Math.cos(r.x),
        z * Math.sin(r.x) + 2,
        z * Math.cos(r.y) * Math.cos(r.x)
      );
      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    const ro = new ResizeObserver(handleResize);
    ro.observe(mount);

    return () => {
      cancelAnimationFrame(frameRef.current);
      ro.disconnect();
      if (mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Execute code on change
  useEffect(() => {
    if (sceneRef.current && code) {
      const result = executeCode(code, sceneRef.current);
      if (!result.success && onError) onError(result.error);
      else if (result.success && onError) onError(null);
    }
  }, [code, onError]);

  const handleMouseDown = (e) => {
    mouseRef.current = { isDown: true, x: e.clientX, y: e.clientY };
  };
  const handleMouseMove = (e) => {
    if (!mouseRef.current.isDown) return;
    const dx = e.clientX - mouseRef.current.x;
    const dy = e.clientY - mouseRef.current.y;
    rotRef.current.y += dx * 0.005;
    rotRef.current.x = Math.max(-1.2, Math.min(1.2, rotRef.current.x + dy * 0.005));
    mouseRef.current.x = e.clientX;
    mouseRef.current.y = e.clientY;
  };
  const handleMouseUp = () => { mouseRef.current.isDown = false; };
  const handleWheel = (e) => {
    zoomRef.current = Math.max(3, Math.min(30, zoomRef.current + e.deltaY * 0.01));
  };

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      <div
        ref={mountRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
        style={{ width: '100%', height: '100%', cursor: 'grab' }}
      />
      <div style={{
        position: 'absolute', bottom: 16, left: 16,
        fontSize: 10, color: T.textMuted, background: `${T.bg}cc`,
        padding: '6px 10px', borderRadius: 6, backdropFilter: 'blur(8px)',
        userSelect: 'none',
      }}>
        🖱 Drag to orbit · Scroll to zoom
      </div>
    </div>
  );
}
