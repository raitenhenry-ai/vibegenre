import { useState, useRef, useEffect } from 'react';
import T from '../theme';
import { SYSTEM_PROMPT } from '../utils/systemPrompt';
import { extractCode } from '../utils/executeCode';

const WELCOME_MSG = {
  role: 'assistant',
  content: "Hey! I'm your 3D modeling AI. Describe what you want to build and I'll generate the Three.js code.\n\nTry: \"Create a snowman\" or \"Make a rocket ship\"",
};

export default function ChatPanel({ code, onCodeGenerated }) {
  const [messages, setMessages] = useState([WELCOME_MSG]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    const msg = input.trim();
    if (!msg || isLoading) return;

    const newMessages = [...messages, { role: 'user', content: msg }];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const apiMessages = newMessages
        .filter((m) => m.role !== 'system')
        .map((m) => ({ role: m.role, content: m.content }));

      // Add current code context
      apiMessages[apiMessages.length - 1].content += `\n\n[Current scene code:\n${code}\n]`;

      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 4000,
          system: SYSTEM_PROMPT,
          messages: apiMessages,
        }),
      });

      const data = await response.json();
      const aiText = data.content?.map((b) => b.text || '').join('') || 'Sorry, something went wrong.';

      const { cleanCode, looksLikeCode } = extractCode(aiText);

      if (looksLikeCode) {
        setMessages([...newMessages, { role: 'assistant', content: '✨ Generated! Check the code editor →' }]);
        onCodeGenerated(cleanCode);
      } else {
        setMessages([...newMessages, { role: 'assistant', content: aiText }]);
      }
    } catch (err) {
      setMessages([...newMessages, { role: 'assistant', content: `Error: ${err.message}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Messages */}
      <div style={{ flex: 1, overflow: 'auto', padding: 12 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{
            marginBottom: 12, display: 'flex', flexDirection: 'column',
            alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start',
          }}>
            <div style={{
              maxWidth: '90%', padding: '10px 14px', borderRadius: 12,
              background: msg.role === 'user' ? T.accentDim : T.surface,
              border: msg.role === 'user' ? `1px solid ${T.accent}44` : `1px solid ${T.panelBorder}`,
              fontSize: 13, lineHeight: 1.5, whiteSpace: 'pre-wrap',
              fontFamily: T.fontSans,
            }}>
              {msg.content}
            </div>
          </div>
        ))}
        {isLoading && (
          <div style={{ padding: '10px 14px', fontSize: 13, color: T.textDim }}>
            <span className="pulse-anim">Generating 3D...</span>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input */}
      <div style={{ padding: 12, borderTop: `1px solid ${T.panelBorder}` }}>
        <div style={{
          display: 'flex', gap: 8, alignItems: 'flex-end',
          background: T.surface, borderRadius: 10, padding: 8,
          border: `1px solid ${T.panelBorder}`,
        }}>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Describe a 3D object..."
            rows={2}
            style={{
              flex: 1, resize: 'none', border: 'none', outline: 'none',
              background: 'transparent', color: T.text, fontFamily: T.fontSans,
              fontSize: 13, lineHeight: 1.4,
            }}
          />
          <button
            onClick={sendMessage}
            disabled={isLoading || !input.trim()}
            style={{
              width: 36, height: 36, borderRadius: 8, border: 'none',
              cursor: isLoading || !input.trim() ? 'not-allowed' : 'pointer',
              background: input.trim() ? T.accent : T.textMuted,
              color: '#000', fontSize: 16, fontWeight: 700,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              opacity: isLoading || !input.trim() ? 0.4 : 1,
              transition: 'all 0.2s', flexShrink: 0,
            }}
          >
            ↑
          </button>
        </div>
        <div style={{ fontSize: 10, color: T.textMuted, marginTop: 6, textAlign: 'center' }}>
          Try: "Chess pawn" · "House with chimney" · "Palm tree"
        </div>
      </div>
    </div>
  );
}
