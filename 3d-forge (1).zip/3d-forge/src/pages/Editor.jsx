import { useState, useCallback } from 'react';
import T from '../theme';
import { DEFAULT_CODE } from '../utils/systemPrompt';
import Viewport from '../components/Viewport';
import ChatPanel from '../components/ChatPanel';
import CodePanel from '../components/CodePanel';
import TopBar from '../components/TopBar';

export default function Editor() {
  const [code, setCode] = useState(DEFAULT_CODE);
  const [liveCode, setLiveCode] = useState(DEFAULT_CODE);
  const [codeError, setCodeError] = useState(null);
  const [activeTab, setActiveTab] = useState('chat');
  const [panelWidth, setPanelWidth] = useState(380);
  const [isDragging, setIsDragging] = useState(false);

  const runCode = useCallback(() => {
    setCodeError(null);
    setLiveCode(code);
  }, [code]);

  const handleCodeGenerated = useCallback((newCode) => {
    setCode(newCode);
    setLiveCode(newCode);
    setCodeError(null);
    setActiveTab('code');
  }, []);

  // Resizable panel
  const handleResizeStart = (e) => {
    e.preventDefault();
    setIsDragging(true);
    const startX = e.clientX;
    const startWidth = panelWidth;

    const onMove = (ev) => {
      const newWidth = Math.max(280, Math.min(600, startWidth + ev.clientX - startX));
      setPanelWidth(newWidth);
    };
    const onUp = () => {
      setIsDragging(false);
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  };

  const tabs = [
    { id: 'chat', label: '💬 AI Chat' },
    { id: 'code', label: '⟨/⟩ Code' },
  ];

  return (
    <div style={{
      width: '100vw', height: '100vh', display: 'flex', flexDirection: 'column',
      background: T.bg, color: T.text, fontFamily: T.font, overflow: 'hidden',
    }}>
      <TopBar codeError={codeError} onRun={runCode} />

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Left Panel */}
        <div style={{
          width: panelWidth, minWidth: 280, display: 'flex', flexDirection: 'column',
          background: T.panel, flexShrink: 0,
        }}>
          {/* Tabs */}
          <div style={{ display: 'flex', borderBottom: `1px solid ${T.panelBorder}` }}>
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  flex: 1, padding: '11px 0', border: 'none', cursor: 'pointer',
                  background: activeTab === tab.id ? T.surface : 'transparent',
                  color: activeTab === tab.id ? T.accent : T.textDim,
                  fontFamily: T.font, fontSize: 12, fontWeight: 600,
                  textTransform: 'uppercase', letterSpacing: '0.08em',
                  borderBottom: activeTab === tab.id ? `2px solid ${T.accent}` : '2px solid transparent',
                  transition: 'all 0.2s',
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Panel Content */}
          {activeTab === 'chat' && (
            <ChatPanel code={code} onCodeGenerated={handleCodeGenerated} />
          )}
          {activeTab === 'code' && (
            <CodePanel code={code} setCode={setCode} onRun={runCode} />
          )}
        </div>

        {/* Resize handle */}
        <div
          onMouseDown={handleResizeStart}
          style={{
            width: 5, cursor: 'col-resize', flexShrink: 0,
            background: isDragging ? T.accent : T.panelBorder,
            transition: isDragging ? 'none' : 'background 0.2s',
            position: 'relative', zIndex: 10,
          }}
          onMouseEnter={(e) => { if (!isDragging) e.target.style.background = T.textMuted; }}
          onMouseLeave={(e) => { if (!isDragging) e.target.style.background = T.panelBorder; }}
        />

        {/* Viewport */}
        <div style={{ flex: 1, position: 'relative' }}>
          <Viewport code={liveCode} onError={setCodeError} />

          {/* Status */}
          <div style={{
            position: 'absolute', top: 16, right: 16,
            display: 'flex', alignItems: 'center', gap: 6,
            fontSize: 10, color: codeError ? T.error : T.accent,
            background: `${T.bg}cc`, padding: '6px 10px', borderRadius: 6,
            backdropFilter: 'blur(8px)',
          }}>
            <div style={{
              width: 6, height: 6, borderRadius: '50%',
              background: codeError ? T.error : T.accent,
              boxShadow: codeError ? 'none' : T.accentGlow,
            }} />
            {codeError ? 'Error' : 'Live'}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        .pulse-anim { animation: pulse 1.5s infinite; }
      `}</style>
    </div>
  );
}
