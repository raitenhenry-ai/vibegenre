import { useState } from 'react';
import { useAuth } from '../App';
import T from '../theme';

export default function Auth() {
  const { login } = useAuth();
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }
    if (isSignup && !name) {
      setError('Please enter your name');
      return;
    }
    // Mock auth — just log them in
    login(email, name);
  };

  return (
    <div style={{
      width: '100vw', height: '100vh', display: 'flex',
      background: T.bg, fontFamily: T.fontSans,
      overflow: 'hidden', position: 'relative',
    }}>
      {/* Animated background grid */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.06,
        backgroundImage: `
          linear-gradient(${T.accent} 1px, transparent 1px),
          linear-gradient(90deg, ${T.accent} 1px, transparent 1px)
        `,
        backgroundSize: '60px 60px',
        animation: 'gridMove 20s linear infinite',
      }} />

      {/* Glow orbs */}
      <div style={{
        position: 'absolute', width: 500, height: 500, borderRadius: '50%',
        background: `radial-gradient(circle, ${T.accent}15 0%, transparent 70%)`,
        top: '-10%', right: '-5%', filter: 'blur(60px)',
      }} />
      <div style={{
        position: 'absolute', width: 400, height: 400, borderRadius: '50%',
        background: `radial-gradient(circle, #4488ff15 0%, transparent 70%)`,
        bottom: '-10%', left: '-5%', filter: 'blur(60px)',
      }} />

      {/* Left side — branding */}
      <div style={{
        flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center',
        padding: '0 80px', position: 'relative', zIndex: 1,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <div style={{
            width: 48, height: 48, borderRadius: 12,
            background: `linear-gradient(135deg, ${T.accent}, #007a55)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 24, fontWeight: 800, color: '#000',
            boxShadow: `0 0 40px ${T.accent}44`,
          }}>◇</div>
          <span style={{ fontWeight: 800, fontSize: 28, color: T.text, letterSpacing: '-0.04em' }}>
            3D FORGE
          </span>
        </div>

        <h1 style={{
          fontSize: 52, fontWeight: 800, lineHeight: 1.1,
          color: T.text, letterSpacing: '-0.04em', marginBottom: 20,
          maxWidth: 500,
        }}>
          Describe it.{' '}
          <span style={{ color: T.accent }}>Build it.</span>
        </h1>
        <p style={{
          fontSize: 18, color: T.textDim, lineHeight: 1.6, maxWidth: 440,
        }}>
          AI-powered 3D modeling. Go from text descriptions to exportable 3D models
          in seconds. No CAD experience needed.
        </p>

        <div style={{
          display: 'flex', gap: 24, marginTop: 48, color: T.textMuted, fontSize: 13,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ color: T.accent }}>◆</span> Text to 3D
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ color: T.accent }}>◆</span> Live code editor
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ color: T.accent }}>◆</span> Export STL/OBJ
          </div>
        </div>
      </div>

      {/* Right side — auth form */}
      <div style={{
        width: 480, display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', zIndex: 1,
      }}>
        <div style={{
          width: 380, padding: 40, borderRadius: 20,
          background: `${T.panel}ee`, border: `1px solid ${T.panelBorder}`,
          backdropFilter: 'blur(20px)',
          boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
        }}>
          <h2 style={{
            fontSize: 22, fontWeight: 700, marginBottom: 6,
            color: T.text, letterSpacing: '-0.02em',
          }}>
            {isSignup ? 'Create account' : 'Welcome back'}
          </h2>
          <p style={{ fontSize: 13, color: T.textDim, marginBottom: 28 }}>
            {isSignup ? 'Start building 3D models with AI' : 'Sign in to your workspace'}
          </p>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {isSignup && (
              <div>
                <label style={{ fontSize: 11, color: T.textDim, fontWeight: 600, marginBottom: 6, display: 'block', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Name
                </label>
                <input
                  type="text" value={name} onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  style={{
                    width: '100%', padding: '11px 14px', borderRadius: 10,
                    border: `1px solid ${T.panelBorder}`, background: T.surface,
                    color: T.text, fontSize: 14, fontFamily: T.fontSans,
                    outline: 'none', transition: 'border 0.2s',
                  }}
                  onFocus={(e) => e.target.style.borderColor = T.accent}
                  onBlur={(e) => e.target.style.borderColor = T.panelBorder}
                />
              </div>
            )}

            <div>
              <label style={{ fontSize: 11, color: T.textDim, fontWeight: 600, marginBottom: 6, display: 'block', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Email
              </label>
              <input
                type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                style={{
                  width: '100%', padding: '11px 14px', borderRadius: 10,
                  border: `1px solid ${T.panelBorder}`, background: T.surface,
                  color: T.text, fontSize: 14, fontFamily: T.fontSans,
                  outline: 'none', transition: 'border 0.2s',
                }}
                onFocus={(e) => e.target.style.borderColor = T.accent}
                onBlur={(e) => e.target.style.borderColor = T.panelBorder}
              />
            </div>

            <div>
              <label style={{ fontSize: 11, color: T.textDim, fontWeight: 600, marginBottom: 6, display: 'block', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Password
              </label>
              <input
                type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                style={{
                  width: '100%', padding: '11px 14px', borderRadius: 10,
                  border: `1px solid ${T.panelBorder}`, background: T.surface,
                  color: T.text, fontSize: 14, fontFamily: T.fontSans,
                  outline: 'none', transition: 'border 0.2s',
                }}
                onFocus={(e) => e.target.style.borderColor = T.accent}
                onBlur={(e) => e.target.style.borderColor = T.panelBorder}
              />
            </div>

            {error && (
              <div style={{ fontSize: 12, color: T.error, padding: '8px 12px', borderRadius: 8, background: `${T.error}15` }}>
                {error}
              </div>
            )}

            <button type="submit" style={{
              padding: '12px 0', borderRadius: 10, border: 'none',
              background: `linear-gradient(135deg, ${T.accent}, #00b882)`,
              color: '#000', fontWeight: 700, fontSize: 14,
              fontFamily: T.fontSans, cursor: 'pointer',
              transition: 'all 0.2s', marginTop: 4,
              boxShadow: `0 4px 20px ${T.accent}33`,
            }}
              onMouseEnter={(e) => e.target.style.transform = 'translateY(-1px)'}
              onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
            >
              {isSignup ? 'Create Account' : 'Sign In'}
            </button>
          </form>

          <div style={{ marginTop: 20, textAlign: 'center' }}>
            <button
              onClick={() => { setIsSignup(!isSignup); setError(''); }}
              style={{
                background: 'none', border: 'none', color: T.accent,
                fontSize: 13, cursor: 'pointer', fontFamily: T.fontSans,
              }}
            >
              {isSignup ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
            </button>
          </div>

          {/* Divider + demo */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12, margin: '20px 0 16px',
          }}>
            <div style={{ flex: 1, height: 1, background: T.panelBorder }} />
            <span style={{ fontSize: 11, color: T.textMuted }}>or</span>
            <div style={{ flex: 1, height: 1, background: T.panelBorder }} />
          </div>

          <button
            onClick={() => login('demo@3dforge.ai', 'Demo User')}
            style={{
              width: '100%', padding: '10px 0', borderRadius: 10,
              border: `1px solid ${T.panelBorder}`, background: T.surface,
              color: T.textDim, fontWeight: 600, fontSize: 13,
              fontFamily: T.fontSans, cursor: 'pointer',
              transition: 'all 0.2s',
            }}
            onMouseEnter={(e) => { e.target.style.background = T.surfaceHover; e.target.style.color = T.text; }}
            onMouseLeave={(e) => { e.target.style.background = T.surface; e.target.style.color = T.textDim; }}
          >
            Try Demo →
          </button>
        </div>
      </div>

      <style>{`
        @keyframes gridMove {
          0% { transform: translate(0, 0); }
          100% { transform: translate(60px, 60px); }
        }
      `}</style>
    </div>
  );
}
