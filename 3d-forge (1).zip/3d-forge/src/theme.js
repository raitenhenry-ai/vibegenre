const theme = {
  bg: "#0a0a0f",
  panel: "#12121a",
  panelBorder: "#1e1e2e",
  surface: "#1a1a28",
  surfaceHover: "#22223a",
  accent: "#00e5a0",
  accentDim: "#00e5a033",
  accentGlow: "0 0 20px #00e5a044",
  accentHover: "#00ffb2",
  text: "#e2e2e8",
  textDim: "#6e6e82",
  textMuted: "#3a3a52",
  error: "#ff5c5c",
  warn: "#ffc44d",
  code: "#c4b5fd",
  font: "'IBM Plex Mono', 'SF Mono', 'Fira Code', monospace",
  fontSans: "'DM Sans', 'Segoe UI', sans-serif",
};

export default theme;
