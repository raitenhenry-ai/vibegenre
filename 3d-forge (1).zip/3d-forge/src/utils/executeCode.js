import * as THREE from 'three';

export function executeCode(code, scene) {
  // Clear existing user objects
  const toRemove = [];
  scene.traverse((child) => {
    if (child.userData?.userObject) toRemove.push(child);
  });
  toRemove.forEach((obj) => {
    if (obj.geometry) obj.geometry.dispose();
    if (obj.material) {
      if (Array.isArray(obj.material)) {
        obj.material.forEach((m) => m.dispose());
      } else {
        obj.material.dispose();
      }
    }
    scene.remove(obj);
  });

  try {
    const wrappedCode = `
      (function(scene, THREE) {
        const _origAdd = scene.add.bind(scene);
        scene.add = function(obj) {
          if (obj) obj.userData = { ...obj.userData, userObject: true };
          return _origAdd(obj);
        };
        ${code}
        scene.add = _origAdd;
      })
    `;
    const fn = eval(wrappedCode);
    fn(scene, THREE);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

export function extractCode(aiText) {
  let cleanCode = aiText;
  // Strip markdown fences
  cleanCode = cleanCode.replace(/^```(?:javascript|js|jsx)?\s*\n?/gm, '').replace(/\n?```\s*$/gm, '');
  // Strip leading english text before first code line
  const codeStartPatterns = [/^const /m, /^let /m, /^var /m, /^\/\//m, /^function /m, /^new THREE/m, /^scene\./m, /^for /m];
  for (const pat of codeStartPatterns) {
    const match = cleanCode.match(pat);
    if (match) {
      const idx = cleanCode.indexOf(match[0]);
      if (idx > 0 && idx < 200) {
        cleanCode = cleanCode.substring(idx);
      }
      break;
    }
  }
  cleanCode = cleanCode.trim();
  const looksLikeCode = cleanCode.includes('THREE.') || cleanCode.includes('scene.add') || cleanCode.includes('new THREE');
  return { cleanCode, looksLikeCode };
}
