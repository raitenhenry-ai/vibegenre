import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState, createContext, useContext } from 'react';
import Auth from './pages/Auth';
import Editor from './pages/Editor';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export default function App() {
  const [user, setUser] = useState(null);

  const login = (email, name) => {
    setUser({ email, name: name || email.split('@')[0] });
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={user ? <Navigate to="/editor" /> : <Auth />} />
          <Route
            path="/editor"
            element={user ? <Editor /> : <Navigate to="/" />}
          />
        </Routes>
      </BrowserRouter>
    </AuthContext.Provider>
  );
}
