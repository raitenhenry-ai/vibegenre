# 3D Forge — AI-Powered 3D Modeling IDE

Describe what you want → AI generates 3D models in real-time.

## Quick Start

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

```bash
npm install -g vercel
vercel
```

## Deploy to Netlify

```bash
npm run build
# Drag the 'dist' folder to app.netlify.com/drop
```

## Project Structure

```
src/
├── main.jsx          # Entry point
├── App.jsx           # Router + auth context
├── theme.js          # Shared design tokens
├── pages/
│   ├── Auth.jsx      # Login / signup page
│   └── Editor.jsx    # Main 3D editor
├── components/
│   ├── Viewport.jsx  # Three.js 3D viewport
│   ├── ChatPanel.jsx # AI chat interface
│   ├── CodePanel.jsx # Code editor
│   └── TopBar.jsx    # Navigation bar
└── utils/
    ├── executeCode.js   # Three.js code executor
    └── systemPrompt.js  # AI system prompt + defaults
```

## Tech Stack

- **React 18** + **Vite**
- **Three.js** for 3D rendering
- **Anthropic API** (Claude) for AI code generation
- **React Router** for navigation

## Notes

- Auth is UI-only for now (no backend). Wire up Supabase/Firebase for real auth.
- The AI API calls are made client-side via the Anthropic API.
- For production, you'll want to proxy API calls through a backend.
